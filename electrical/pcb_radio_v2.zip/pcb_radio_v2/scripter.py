def ping():
	print("pong!")

def ligma():
	print("balls")

if __name__ == "__main__":
	ping()